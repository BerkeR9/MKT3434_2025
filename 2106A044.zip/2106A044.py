import sys
import numpy as np
import pandas as pd
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                           QHBoxLayout, QTabWidget, QPushButton, QLabel, 
                           QComboBox, QFileDialog, QSpinBox, QDoubleSpinBox,
                           QGroupBox, QScrollArea, QTextEdit, QStatusBar,
                           QProgressBar, QCheckBox, QGridLayout, QMessageBox,
                           QDialog, QLineEdit)
from PyQt6.QtCore import Qt
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from sklearn import datasets, preprocessing, model_selection
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC, SVR
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score, mean_squared_error, mean_absolute_error, confusion_matrix
from sklearn.impute import SimpleImputer
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers

class MLCourseGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Machine Learning Course GUI")
        self.setGeometry(100, 100, 1400, 800)
        
        # Initialize main widget and layout
        self.main_widget = QWidget()
        self.setCentralWidget(self.main_widget)
        self.layout = QVBoxLayout(self.main_widget)
        
        # Initialize data containers
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.current_model = None
        self.layer_config = []
        
        # Create components
        self.create_data_section()
        self.create_tabs()
        self.create_visualization()
        self.create_status_bar()

    def create_data_section(self):
        """Create the data loading and preprocessing section"""
        data_group = QGroupBox("Data Management")
        data_layout = QVBoxLayout()  # İlk kodda QHBoxLayout yerine QVBoxLayout kullanılabilir
        
        dataset_layout = QHBoxLayout()
        self.dataset_combo = QComboBox()
        self.dataset_combo.addItems([
            "Load Custom Dataset", "Iris Dataset", "Breast Cancer Dataset",
            "Digits Dataset", "Boston Housing Dataset", "MNIST Dataset"
        ])
        self.dataset_combo.currentIndexChanged.connect(self.load_dataset)
        dataset_layout.addWidget(QLabel("Dataset:"))
        dataset_layout.addWidget(self.dataset_combo)
        
        self.load_btn = QPushButton("Load Data")
        self.load_btn.clicked.connect(self.load_custom_data)
        dataset_layout.addWidget(self.load_btn)
        
        missing_layout = QHBoxLayout()
        self.missing_combo = QComboBox()
        self.missing_combo.addItems(["Mean Imputation", "Interpolation", "Forward Fill", "Backward Fill"])
        missing_layout.addWidget(QLabel("Missing Values:"))
        missing_layout.addWidget(self.missing_combo)
        
        preprocess_layout = QHBoxLayout()
        self.scaling_combo = QComboBox()
        self.scaling_combo.addItems(["No Scaling", "Standard Scaling", "Min-Max Scaling", "Robust Scaling"])
        self.split_spin = QDoubleSpinBox()
        self.split_spin.setRange(0.1, 0.9)
        self.split_spin.setValue(0.2)
        self.split_spin.setSingleStep(0.1)
        preprocess_layout.addWidget(QLabel("Scaling:"))
        preprocess_layout.addWidget(self.scaling_combo)
        preprocess_layout.addWidget(QLabel("Test Split:"))
        preprocess_layout.addWidget(self.split_spin)
        
        data_layout.addLayout(dataset_layout)
        data_layout.addLayout(missing_layout)
        data_layout.addLayout(preprocess_layout)
        data_group.setLayout(data_layout)
        self.layout.addWidget(data_group)

    def load_dataset(self):
        """Load selected dataset"""
        try:
            dataset_name = self.dataset_combo.currentText()
            if dataset_name == "Load Custom Dataset":
                return
            
            if dataset_name == "Iris Dataset":
                data = datasets.load_iris()
            elif dataset_name == "Breast Cancer Dataset":
                data = datasets.load_breast_cancer()
            elif dataset_name == "Digits Dataset":
                data = datasets.load_digits()
            elif dataset_name == "Boston Housing Dataset":
                data = datasets.load_boston()
            elif dataset_name == "MNIST Dataset":
                (X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()
                self.X_train, self.X_test = X_train, X_test
                self.y_train, self.y_test = y_train, y_test
                self.status_bar.showMessage(f"Loaded {dataset_name}")
                return
            
            X, y = data.data, data.target
            X = self.handle_missing_values(X)
            test_size = self.split_spin.value()
            self.X_train, self.X_test, self.y_train, self.y_test = \
                model_selection.train_test_split(X, y, test_size=test_size, random_state=42)
            self.apply_scaling()
            self.status_bar.showMessage(f"Loaded {dataset_name}")
            
        except Exception as e:
            self.show_error(f"Error loading dataset: {str(e)}")

    def load_custom_data(self):
        """Load custom dataset from CSV file"""
        try:
            file_name, _ = QFileDialog.getOpenFileName(self, "Load Dataset", "", "CSV files (*.csv)")
            if file_name:
                data = pd.read_csv(file_name)
                target_col = self.select_target_column(data.columns)
                if target_col:
                    X = data.drop(target_col, axis=1)
                    y = data[target_col]
                    
                    if y.dtype == 'object':
                        y = y.map({'M': 0, 'B': 1})
                    
                    if 'id' in X.columns:
                        X = X.drop('id', axis=1)
                    
                    X = self.handle_missing_values(X)
                    
                    test_size = self.split_spin.value()
                    self.X_train, self.X_test, self.y_train, self.y_test = \
                        model_selection.train_test_split(X, y, test_size=test_size, random_state=42)
                    self.apply_scaling()
                    self.status_bar.showMessage(f"Loaded custom dataset: {file_name}")
        except Exception as e:
            self.show_error(f"Error loading custom dataset: {str(e)}")

    def handle_missing_values(self, X):
        """Handle missing values in the dataset"""
        method = self.missing_combo.currentText()
        if method == "Mean Imputation":
            imputer = SimpleImputer(strategy='mean')
            return imputer.fit_transform(X)
        elif method == "Interpolation":
            return pd.DataFrame(X).interpolate().to_numpy()
        elif method == "Forward Fill":
            return pd.DataFrame(X).fillna(method='ffill').to_numpy()
        elif method == "Backward Fill":
            return pd.DataFrame(X).fillna(method='bfill').to_numpy()
        return X

    def apply_scaling(self):
        """Apply selected scaling method to the data"""
        scaling_method = self.scaling_combo.currentText()
        if scaling_method != "No Scaling":
            if scaling_method == "Standard Scaling":
                scaler = preprocessing.StandardScaler()
            elif scaling_method == "Min-Max Scaling":
                scaler = preprocessing.MinMaxScaler()
            elif scaling_method == "Robust Scaling":
                scaler = preprocessing.RobustScaler()
            self.X_train = scaler.fit_transform(self.X_train)
            self.X_test = scaler.transform(self.X_test)

    def create_tabs(self):
        """Create tabs for different ML topics"""
        self.tab_widget = QTabWidget()
        tabs = [
            ("Classical ML", self.create_classical_ml_tab),
            ("Deep Learning", self.create_deep_learning_tab),
            ("Dimensionality Reduction", self.create_dim_reduction_tab),
            ("Reinforcement Learning", self.create_rl_tab)
        ]
        for tab_name, create_func in tabs:
            scroll = QScrollArea()
            tab_widget = create_func()
            scroll.setWidget(tab_widget)
            scroll.setWidgetResizable(True)
            self.tab_widget.addTab(scroll, tab_name)
        self.layout.addWidget(self.tab_widget)

    def create_classical_ml_tab(self):
        """Create the classical machine learning algorithms tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        regression_group = QGroupBox("Regression")
        regression_layout = QVBoxLayout()
        
        lr_group = self.create_algorithm_group("Linear Regression", 
            {"fit_intercept": "checkbox"}, 
            ["MSE", "MAE", "Huber Loss"])
        regression_layout.addWidget(lr_group)
        
        svm_reg_group = self.create_algorithm_group("SVM Regression (SVR)",
            {"C": "double", "epsilon": "double", "kernel": ["linear", "rbf", "poly"]},
            ["MSE", "MAE", "Huber Loss"])
        regression_layout.addWidget(svm_reg_group)
        
        regression_group.setLayout(regression_layout)
        layout.addWidget(regression_group, 0, 0)
        
        classification_group = QGroupBox("Classification")
        classification_layout = QVBoxLayout()
        
        logistic_group = self.create_algorithm_group("Logistic Regression",
            {"C": "double", "max_iter": "int", "multi_class": ["ovr", "multinomial"]},
            ["Cross-Entropy", "Hinge Loss"])
        classification_layout.addWidget(logistic_group)
        
        nb_group = self.create_algorithm_group("Naive Bayes",
            {"var_smoothing": "double", "priors": "custom"},
            ["Cross-Entropy"])
        classification_layout.addWidget(nb_group)
        
        svm_group = self.create_algorithm_group("Support Vector Machine",
            {"C": "double", "kernel": ["linear", "rbf", "poly"], "degree": "int"},
            ["Cross-Entropy", "Hinge Loss"])
        classification_layout.addWidget(svm_group)
        
        dt_group = self.create_algorithm_group("Decision Tree",
            {"max_depth": "int", "min_samples_split": "int", "criterion": ["gini", "entropy"]},
            ["Cross-Entropy"])
        classification_layout.addWidget(dt_group)
        
        rf_group = self.create_algorithm_group("Random Forest",
            {"n_estimators": "int", "max_depth": "int", "min_samples_split": "int"},
            ["Cross-Entropy"])
        classification_layout.addWidget(rf_group)
        
        knn_group = self.create_algorithm_group("K-Nearest Neighbors",
            {"n_neighbors": "int", "weights": ["uniform", "distance"], "metric": ["euclidean", "manhattan"]},
            ["Cross-Entropy"])
        classification_layout.addWidget(knn_group)
        
        classification_group.setLayout(classification_layout)
        layout.addWidget(classification_group, 0, 1)
        
        return widget

    def create_algorithm_group(self, name, params, loss_options=None):
        """Helper method to create algorithm parameter groups"""
        group = QGroupBox(name)
        layout = QVBoxLayout()
        param_widgets = {}
        
        for param_name, param_type in params.items():
            param_layout = QHBoxLayout()
            param_layout.addWidget(QLabel(f"{param_name}:"))
            if param_type == "int":
                widget = QSpinBox()
                widget.setRange(1, 1000)
            elif param_type == "double":
                widget = QDoubleSpinBox()
                widget.setRange(0.0001, 1000.0)
                widget.setSingleStep(0.1)
            elif param_type == "checkbox":
                widget = QCheckBox()
            elif param_type == "custom":
                widget = QLineEdit()
                widget.setPlaceholderText("e.g., 0.3,0.7")
            elif isinstance(param_type, list):
                widget = QComboBox()
                widget.addItems(param_type)
            param_layout.addWidget(widget)
            param_widgets[param_name] = widget
            layout.addLayout(param_layout)
        
        if loss_options:
            loss_layout = QHBoxLayout()
            loss_combo = QComboBox()
            loss_combo.addItems(loss_options)
            param_widgets["loss"] = loss_combo
            loss_layout.addWidget(QLabel("Loss Function:"))
            loss_layout.addWidget(loss_combo)
            layout.addLayout(loss_layout)
        
        train_btn = QPushButton(f"Train {name}")
        train_btn.clicked.connect(lambda: self.train_model(name, param_widgets))
        layout.addWidget(train_btn)
        
        group.setLayout(layout)
        return group

    def train_model(self, model_name, param_widgets):
        """Train the selected machine learning model"""
        try:
            params = {}
            loss_function = param_widgets.get("loss", None)
            if loss_function:
                loss_function = loss_function.currentText()
            for param_name, widget in param_widgets.items():
                if param_name == "loss":
                    continue
                if isinstance(widget, QSpinBox):
                    params[param_name] = widget.value()
                elif isinstance(widget, QDoubleSpinBox):
                    params[param_name] = widget.value()
                elif isinstance(widget, QComboBox):
                    params[param_name] = widget.currentText()
                elif isinstance(widget, QCheckBox):
                    params[param_name] = widget.isChecked()
                elif isinstance(widget, QLineEdit) and param_name == "priors":
                    priors_text = widget.text()
                    if priors_text:
                        params["priors"] = [float(p) for p in priors_text.split(",")]
                    else:
                        params["priors"] = None

            if model_name == "Linear Regression":
                self.current_model = LinearRegression(**params)
            elif model_name == "SVM Regression (SVR)":
                self.current_model = SVR(**params)
            elif model_name == "Logistic Regression":
                self.current_model = LogisticRegression(**params)
            elif model_name == "Naive Bayes":
                self.current_model = GaussianNB(**params)
            elif model_name == "Support Vector Machine":
                self.current_model = SVC(**params)
            elif model_name == "Decision Tree":
                self.current_model = DecisionTreeClassifier(**params)
            elif model_name == "Random Forest":
                self.current_model = RandomForestClassifier(**params)
            elif model_name == "K-Nearest Neighbors":
                self.current_model = KNeighborsClassifier(**params)
            elif model_name == "K-Means Parameters":
                self.current_model = KMeans(**params)
            elif model_name == "PCA Parameters":  # İlk kodda PCA vardı, geri eklendi
                self.current_model = PCA(**params)

            self.current_model.fit(self.X_train, self.y_train)
            y_pred = self.current_model.predict(self.X_test)
            
            self.update_visualization(y_pred)
            self.update_metrics(y_pred, loss_function)
            self.status_bar.showMessage(f"{model_name} training complete")
            
            if model_name == "SVM Regression (SVR)" and self.dataset_combo.currentText() == "Boston Housing Dataset":
                mse = mean_squared_error(self.y_test, y_pred)
                mae = mean_absolute_error(self.y_test, y_pred)
                self.metrics_text.append(f"\nSVR on Boston Housing - MSE: {mse:.4f}, MAE: {mae:.4f}")

        except Exception as e:
            self.show_error(f"Error training {model_name}: {str(e)}")

    def update_metrics(self, y_pred, loss_function=None):
        """Update metrics display"""
        metrics_text = f"Model Performance Metrics{' (Loss: ' + loss_function + ')' if loss_function else ''}:\n\n"
        if loss_function in ["MSE", "MAE", "Huber Loss"]:
            mse = mean_squared_error(self.y_test, y_pred)
            mae = mean_absolute_error(self.y_test, y_pred)
            metrics_text += f"Mean Squared Error: {mse:.4f}\n"
            metrics_text += f"Mean Absolute Error: {mae:.4f}\n"
        else:
            accuracy = accuracy_score(self.y_test, y_pred)
            conf_matrix = confusion_matrix(self.y_test, y_pred)  # İlk kodda vardı, geri eklendi
            metrics_text += f"Accuracy: {accuracy:.4f}\n\n"
            metrics_text += "Confusion Matrix:\n"
            metrics_text += str(conf_matrix)
        self.metrics_text.setText(metrics_text)

    def create_deep_learning_tab(self):
        """Create the deep learning tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        mlp_group = QGroupBox("Multi-Layer Perceptron")
        mlp_layout = QVBoxLayout()
        self.layer_config = []
        layer_btn = QPushButton("Add Layer")
        layer_btn.clicked.connect(self.add_layer_dialog)
        mlp_layout.addWidget(layer_btn)
        
        training_params_group = self.create_training_params_group()
        mlp_layout.addWidget(training_params_group)
        
        train_btn = QPushButton("Train Neural Network")
        train_btn.clicked.connect(self.train_neural_network)
        mlp_layout.addWidget(train_btn)
        
        mlp_group.setLayout(mlp_layout)
        layout.addWidget(mlp_group, 0, 0)
        
        # CNN section geri eklendi
        cnn_group = QGroupBox("Convolutional Neural Network")
        cnn_layout = QVBoxLayout()
        cnn_controls = self.create_cnn_controls()
        cnn_layout.addWidget(cnn_controls)
        cnn_group.setLayout(cnn_layout)
        layout.addWidget(cnn_group, 0, 1)
        
        # RNN section geri eklendi
        rnn_group = QGroupBox("Recurrent Neural Network")
        rnn_layout = QVBoxLayout()
        rnn_controls = self.create_rnn_controls()
        rnn_layout.addWidget(rnn_controls)
        rnn_group.setLayout(rnn_layout)
        layout.addWidget(rnn_group, 1, 0)
        
        return widget

    def create_training_params_group(self):
        """Create group for neural network training parameters"""
        group = QGroupBox("Training Parameters")
        layout = QVBoxLayout()
        
        batch_layout = QHBoxLayout()
        batch_layout.addWidget(QLabel("Batch Size:"))
        self.batch_size_spin = QSpinBox()
        self.batch_size_spin.setRange(1, 1000)
        self.batch_size_spin.setValue(32)
        batch_layout.addWidget(self.batch_size_spin)
        layout.addLayout(batch_layout)
        
        epochs_layout = QHBoxLayout()
        epochs_layout.addWidget(QLabel("Epochs:"))
        self.epochs_spin = QSpinBox()
        self.epochs_spin.setRange(1, 1000)
        self.epochs_spin.setValue(10)
        epochs_layout.addWidget(self.epochs_spin)
        layout.addLayout(epochs_layout)
        
        lr_layout = QHBoxLayout()
        lr_layout.addWidget(QLabel("Learning Rate:"))
        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setRange(0.0001, 1.0)
        self.lr_spin.setValue(0.001)
        self.lr_spin.setSingleStep(0.001)
        lr_layout.addWidget(self.lr_spin)
        layout.addLayout(lr_layout)
        
        loss_layout = QHBoxLayout()
        self.nn_loss_combo = QComboBox()
        self.nn_loss_combo.addItems(["Cross-Entropy", "MSE", "MAE", "Huber Loss"])
        loss_layout.addWidget(QLabel("Loss Function:"))
        loss_layout.addWidget(self.nn_loss_combo)
        layout.addLayout(loss_layout)
        
        group.setLayout(layout)
        return group

    def create_cnn_controls(self):
        """Create controls for Convolutional Neural Network"""
        group = QGroupBox("CNN Architecture")
        layout = QVBoxLayout()
        label = QLabel("CNN Controls (To be implemented)")
        layout.addWidget(label)
        group.setLayout(layout)
        return group

    def create_rnn_controls(self):
        """Create controls for Recurrent Neural Network"""
        group = QGroupBox("RNN Architecture")
        layout = QVBoxLayout()
        label = QLabel("RNN Controls (To be implemented)")
        layout.addWidget(label)
        group.setLayout(layout)
        return group

    def train_neural_network(self):
        """Train the neural network with current configuration"""
        if not self.layer_config:
            self.show_error("Please add at least one layer")
            return
        try:
            model = self.create_neural_network()
            batch_size = self.batch_size_spin.value()
            epochs = self.epochs_spin.value()
            learning_rate = self.lr_spin.value()
            loss_function = self.nn_loss_combo.currentText().lower().replace(" ", "_")
            
            if len(self.X_train.shape) == 1:
                X_train = self.X_train.reshape(-1, 1)
                X_test = self.X_test.reshape(-1, 1)
            else:
                X_train = self.X_train
                X_test = self.X_test
            
            y_train = tf.keras.utils.to_categorical(self.y_train) if "cross_entropy" in loss_function else self.y_train
            y_test = tf.keras.utils.to_categorical(self.y_test) if "cross_entropy" in loss_function else self.y_test
            
            optimizer = optimizers.Adam(learning_rate=learning_rate)
            model.compile(optimizer=optimizer, loss=loss_function, metrics=['accuracy' if "cross_entropy" in loss_function else 'mae'])
            history = model.fit(X_train, y_train, batch_size=batch_size, epochs=epochs,
                              validation_data=(X_test, y_test), callbacks=[self.create_progress_callback()])
            self.plot_training_history(history)
            self.status_bar.showMessage("Neural Network Training Complete")
        except Exception as e:
            self.show_error(f"Error training neural network: {str(e)}")

    def create_neural_network(self):
        """Create neural network based on current configuration"""
        model = models.Sequential()
        for layer_config in self.layer_config:
            layer_type = layer_config["type"]
            params = layer_config["params"]
            if layer_type == "Dense":
                model.add(layers.Dense(**params))
            elif layer_type == "Conv2D":
                if len(model.layers) == 0:
                    params['input_shape'] = self.X_train.shape[1:]
                model.add(layers.Conv2D(**params))
            elif layer_type == "MaxPooling2D":
                model.add(layers.MaxPooling2D())
            elif layer_type == "Flatten":
                model.add(layers.Flatten())
            elif layer_type == "Dropout":
                model.add(layers.Dropout(**params))
        num_classes = len(np.unique(self.y_train))
        activation = 'softmax' if self.nn_loss_combo.currentText() == "Cross-Entropy" else 'linear'
        model.add(layers.Dense(num_classes if self.nn_loss_combo.currentText() == "Cross-Entropy" else 1, activation=activation))
        return model

    def create_dim_reduction_tab(self):
        """Create the dimensionality reduction tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        kmeans_group = QGroupBox("K-Means Clustering")
        kmeans_layout = QVBoxLayout()
        kmeans_params = self.create_algorithm_group("K-Means Parameters",
            {"n_clusters": "int", "max_iter": "int", "n_init": "int"}, ["MSE"])
        kmeans_layout.addWidget(kmeans_params)
        kmeans_group.setLayout(kmeans_layout)
        layout.addWidget(kmeans_group, 0, 0)
        
        # PCA section geri eklendi
        pca_group = QGroupBox("Principal Component Analysis")
        pca_layout = QVBoxLayout()
        pca_params = self.create_algorithm_group("PCA Parameters",
            {"n_components": "int", "whiten": "checkbox"}, [])
        pca_layout.addWidget(pca_params)
        pca_group.setLayout(pca_layout)
        layout.addWidget(pca_group, 0, 1)
        
        return widget

    def create_rl_tab(self):
        """Create the reinforcement learning tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        env_group = QGroupBox("Environment")
        env_layout = QVBoxLayout()
        self.env_combo = QComboBox()
        self.env_combo.addItems(["CartPole-v1", "MountainCar-v0", "Acrobot-v1"])
        env_layout.addWidget(self.env_combo)
        env_group.setLayout(env_layout)
        layout.addWidget(env_group, 0, 0)
        
        # RL Algorithm section geri eklendi
        algo_group = QGroupBox("RL Algorithm")
        algo_layout = QVBoxLayout()
        self.rl_algo_combo = QComboBox()
        self.rl_algo_combo.addItems(["Q-Learning", "SARSA", "DQN"])
        algo_layout.addWidget(self.rl_algo_combo)
        algo_group.setLayout(algo_layout)
        layout.addWidget(algo_group, 0, 1)
        
        return widget

    def create_visualization(self):
        """Create the visualization section"""
        viz_group = QGroupBox("Visualization")
        viz_layout = QHBoxLayout()
        self.figure = Figure(figsize=(8, 6))
        self.canvas = FigureCanvas(self.figure)
        viz_layout.addWidget(self.canvas)
        self.metrics_text = QTextEdit()
        self.metrics_text.setReadOnly(True)
        viz_layout.addWidget(self.metrics_text)
        viz_group.setLayout(viz_layout)
        self.layout.addWidget(viz_group)

    def create_status_bar(self):
        """Create the status bar"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.progress_bar = QProgressBar()
        self.status_bar.addPermanentWidget(self.progress_bar)

    def update_visualization(self, y_pred):
        """Update the visualization with current results"""
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        if len(np.unique(self.y_test)) > 10:
            ax.scatter(self.y_test, y_pred)
            ax.plot([self.y_test.min(), self.y_test.max()], [self.y_test.min(), self.y_test.max()], 'r--', lw=2)
            ax.set_xlabel("Actual Values")  # İlk kodda böyleydi
            ax.set_ylabel("Predicted Values")
        else:
            if self.X_train.shape[1] > 2:
                pca = PCA(n_components=2)
                X_test_2d = pca.fit_transform(self.X_test)
                scatter = ax.scatter(X_test_2d[:, 0], X_test_2d[:, 1], c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
            else:
                scatter = ax.scatter(self.X_test[:, 0], self.X_test[:, 1], c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
        self.canvas.draw()

    def plot_training_history(self, history):
        """Plot neural network training history"""
        self.figure.clear()
        ax1 = self.figure.add_subplot(211)
        ax1.plot(history.history['accuracy' if 'accuracy' in history.history else 'mae'])
        ax1.plot(history.history['val_' + ('accuracy' if 'accuracy' in history.history else 'mae')])
        ax1.set_title('Model Accuracy' if 'accuracy' in history.history else 'Model Performance')
        ax1.set_ylabel('Accuracy' if 'accuracy' in history.history else 'MAE')
        ax1.set_xlabel('Epoch')
        ax1.legend(['Train', 'Test'])
        
        ax2 = self.figure.add_subplot(212)
        ax2.plot(history.history['loss'])
        ax2.plot(history.history['val_loss'])
        ax2.set_title('Model Loss')
        ax2.set_ylabel('Loss')
        ax2.set_xlabel('Epoch')
        ax2.legend(['Train', 'Test'])
        self.figure.tight_layout()
        self.canvas.draw()

    def create_progress_callback(self):
        """Create callback for updating progress bar during training"""
        class ProgressCallback(tf.keras.callbacks.Callback):
            def __init__(self, progress_bar):
                super().__init__()
                self.progress_bar = progress_bar
            def on_epoch_end(self, epoch, logs=None):
                progress = int(((epoch + 1) / self.params['epochs']) * 100)
                self.progress_bar.setValue(progress)
        return ProgressCallback(self.progress_bar)

    def add_layer_dialog(self):
        """Open a dialog to add a neural network layer"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Add Neural Network Layer")
        layout = QVBoxLayout(dialog)
        
        type_layout = QHBoxLayout()
        type_label = QLabel("Layer Type:")
        type_combo = QComboBox()
        type_combo.addItems(["Dense", "Conv2D", "MaxPooling2D", "Flatten", "Dropout"])
        type_layout.addWidget(type_label)
        type_layout.addWidget(type_combo)
        layout.addLayout(type_layout)
        
        params_group = QGroupBox("Layer Parameters")
        params_layout = QVBoxLayout()
        self.layer_param_inputs = {}
        
        def update_params():
            for widget in list(self.layer_param_inputs.values()):
                params_layout.removeWidget(widget)
                widget.deleteLater()
            self.layer_param_inputs.clear()
            
            layer_type = type_combo.currentText()
            if layer_type == "Dense":
                units_label = QLabel("Units:")
                units_input = QSpinBox()
                units_input.setRange(1, 1000)
                units_input.setValue(32)
                self.layer_param_inputs["units"] = units_input
                
                activation_label = QLabel("Activation:")
                activation_combo = QComboBox()
                activation_combo.addItems(["relu", "sigmoid", "tanh", "softmax"])
                self.layer_param_inputs["activation"] = activation_combo
                
                params_layout.addWidget(units_label)
                params_layout.addWidget(units_input)
                params_layout.addWidget(activation_label)
                params_layout.addWidget(activation_combo)
            
            elif layer_type == "Conv2D":
                filters_label = QLabel("Filters:")
                filters_input = QSpinBox()
                filters_input.setRange(1, 1000)
                filters_input.setValue(32)
                self.layer_param_inputs["filters"] = filters_input
                
                kernel_label = QLabel("Kernel Size:")
                kernel_input = QLineEdit()
                kernel_input.setText("3, 3")
                self.layer_param_inputs["kernel_size"] = kernel_input
                
                params_layout.addWidget(filters_label)
                params_layout.addWidget(filters_input)
                params_layout.addWidget(kernel_label)
                params_layout.addWidget(kernel_input)
            
            elif layer_type == "Dropout":
                rate_label = QLabel("Dropout Rate:")
                rate_input = QDoubleSpinBox()
                rate_input.setRange(0.0, 1.0)
                rate_input.setValue(0.5)
                rate_input.setSingleStep(0.1)
                self.layer_param_inputs["rate"] = rate_input
                
                params_layout.addWidget(rate_label)
                params_layout.addWidget(rate_input)
        
        type_combo.currentIndexChanged.connect(update_params)
        update_params()
        
        params_group.setLayout(params_layout)
        layout.addWidget(params_group)
        
        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Add Layer")
        cancel_btn = QPushButton("Cancel")
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)
        
        def add_layer():
            layer_type = type_combo.currentText()
            layer_params = {}
            for param_name, widget in self.layer_param_inputs.items():
                if isinstance(widget, QSpinBox):
                    layer_params[param_name] = widget.value()
                elif isinstance(widget, QDoubleSpinBox):
                    layer_params[param_name] = widget.value()
                elif isinstance(widget, QComboBox):
                    layer_params[param_name] = widget.currentText()
                elif isinstance(widget, QLineEdit):
                    if param_name == "kernel_size":
                        layer_params[param_name] = tuple(map(int, widget.text().split(',')))
            
            self.layer_config.append({"type": layer_type, "params": layer_params})
            dialog.accept()
        
        add_btn.clicked.connect(add_layer)
        cancel_btn.clicked.connect(dialog.reject)
        dialog.exec()

    def select_target_column(self, columns):
        """Dialog to select target column from dataset"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Target Column")
        layout = QVBoxLayout(dialog)
        combo = QComboBox()
        combo.addItems(columns)
        layout.addWidget(combo)
        btn = QPushButton("Select")
        btn.clicked.connect(dialog.accept)
        layout.addWidget(btn)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            return combo.currentText()
        return None

    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)

def main():
    """Main function to start the application"""
    app = QApplication(sys.argv)
    window = MLCourseGUI()
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()